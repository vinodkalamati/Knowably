# WebCrawlerService

WebCrawler is a web search engine, and is the oldest surviving search engine on the web today. For many years, it operated as a metasearch engine. WebCrawler was the first web search engine to provide full text search.

1.upload links to the webcrawler using RestApi
2.returns payload(Extracted Content from the Webpage) to the RestApi
