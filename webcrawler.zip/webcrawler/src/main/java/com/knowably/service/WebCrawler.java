package com.knowably.service;

import com.knowably.model.Input;
import com.knowably.model.WebCrawl;
import org.springframework.kafka.annotation.KafkaListener;

import java.util.List;

public interface WebCrawler {

    public List<WebCrawl> getContent(Input input);

    /*@KafkaListener(topics = "TopicTest",groupId = "group_id")
    void consume(String msg);*/
}
